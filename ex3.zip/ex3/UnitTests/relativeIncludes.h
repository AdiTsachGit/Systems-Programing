#ifndef RELATIVE_INCLUDES_EXE3_TESTS
#define RELATIVE_INCLUDES_EXE3_TESTS

#include "../HealthPoints.h"
#include "../Queue.h"

#endif // RELATIVE_INCLUDES_EXE3_TESTS