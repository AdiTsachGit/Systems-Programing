//
// Created by Adi on 15/12/2022.
//

#ifndef MTMCHKIN_HEALTHPOINTS_H
#define MTMCHKIN_HEALTHPOINTS_H

#include <iostream>
#include <stdio.h>
#define MAX_HP 100

class HealthPoints
{
public:
    /*
     * C'tor of HealthPoints:
     * @param hp - max and start hp.
     *      An instance of HealthPoints
    */
    HealthPoints(int hp = MAX_HP);

    /*
    * Here we explicitly tell the compiler to use the default methods
    */
    HealthPoints(const HealthPoints& hp) = default;
    ~HealthPoints()=default;
    HealthPoints& operator=(const HealthPoints& hp)=default;


    /*
    *operators and friend operators for Health Points
    */
    HealthPoints& operator+=(int hp);
    HealthPoints& operator-=(int hp);

    friend bool operator==(HealthPoints hp1, HealthPoints hp2);
    friend bool operator<=(HealthPoints hp1, HealthPoints hp2);
    friend std::ostream& operator<<(std::ostream& os, const HealthPoints& hp);

    /*
    *class of exceptions
    */
    class InvalidArgument {};

private:
    int m_hp;
    int m_maxHP;

};

/*
*external operators and friend operators for Health Points
*/
HealthPoints operator+(HealthPoints& hp1, int hp2) ;
HealthPoints operator+(int hp1, HealthPoints& hp2) ;
HealthPoints operator-(HealthPoints& hp1, int hp) ;

bool operator!=(HealthPoints hp1, HealthPoints hp2);
bool operator<(HealthPoints hp1, HealthPoints hp2);
bool operator>=(HealthPoints hp1, HealthPoints hp2);
bool operator>(HealthPoints hp1, HealthPoints hp2);


#endif //MTMCHKIN_HEALTHPOINTS_H
