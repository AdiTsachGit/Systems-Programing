
#ifndef EX3_QUEUE_H
#define EX3_QUEUE_H

#include <iostream>




template <class T>
class Queue {
private:
   /*
    * Pointer to first Node in list
   */
    class Node;
    
    Node* m_top;


public:
    /*
    * C'tor of Queue class
    *
    * @return
    *      A new instance of Card.
    */
    explicit Queue ();

    /*
    * Copy Constructor of Queue class
    *
    * @param queue - a reference to Queue.
    * @return
    *      A new instance of Queue.
    */
    Queue(const Queue& queue);

    /*
    * Destructor of Queue class
    */
    ~Queue();

    /*
    * Assignment operator of Queue class
    *
    * @param other - a reference to Queue.
    * @return
    *      A referance to this Queue.
    */
    Queue<T>& operator=(const Queue& other);

    /*
     * A const function of Queue class that returns the amount of objects held in queue.
     *
     * @return
     *      A const int for the amount of objects in queue.
    */
    const int size() const;

    
    /*
      * Function of Queue class that adds an object to end of queue.
      *
      * @param data - a reference to T type element.
      *
     */
    void pushBack (const T& data);

    
    /*
      * Function of Queue class that returns reference to the first object in queue.
      *
      * @return
      *      A reference to the first object in queue.
     */
    T& front();

    /*
     * A const function of Queue class that returns reference to the first object in queue.
     *
     * @return
     *      A const reference to the first object in queue.
    */
    const T& front() const;

    /*
     * Function of Queue class that let out the last object in queue.
     *
     */
    void popFront();

    /*
    * EmptyQueue class inside Queue class to allow exception throwing.
    *
   */
    class EmptyQueue{};

    /*
    * Iterator class inside Queue class
    *
   */
    class Iterator;

    /*
    * A function of Queue class that returns iterator to start of queue.
    *
    * @return
    *      An iterator to start of queue.
   */
    Iterator begin();

    /*
    * A function of Queue class that returns iterator to end of queue.
    *
    * @return
    *      An iterator to end of queue.
   */
    Iterator end();

    
    /*
    * ConstIterator class inside Queue class
    *
   */
    class ConstIterator;

    /*
    * A function of Queue class that returns const iterator to start of queue.
    *
    * @return
    *      A const iterator to start of queue.
   */
    ConstIterator begin() const;

    
    /*
    * A function of Queue class that returns const iterator to end of queue.
    *
    * @return
    *      A const iterator to end of queue.
   */
    ConstIterator end() const;
};

/*
* A function that gets a Queue and a function object and return a new Queue created base on the original queue,
*but contain just the elements that fit to a certain condition.
*@param: queue- the original queue. c- the function object that determane the condition.
*return- a new Queue object 
*/
template<class T,class Condition>
Queue<T> filter (const Queue<T>& queue , Condition c);

/*
* A function that gets a function object and a Queue object and and can change it's elements due 
* to a certain condition determaned in a the function obeject.
* @param queue- the queue to change. c- the function object that determane the condition.
*/
template<class T,class Condition>
void transform (Queue<T>& queue , Condition c) ;


template <class T>
Queue<T>::Queue():
m_top(nullptr){}

template <class T>
Queue<T>::Queue(const Queue& queue) :
m_top(nullptr){
    if(queue.size() == 0) {
        return;
    }
    Queue<T> newQueue;
    Node* newTop = new Node(queue.m_top->m_data);
    Node* tmp = queue.m_top;
    newQueue.m_top = newTop;
    Node* thisTmp = newQueue.m_top;
    Node* nextNode;
    while (tmp->m_next != nullptr) {
        tmp = tmp->m_next;
        nextNode = new Node(tmp->m_data);
        thisTmp->m_next = nextNode;
        thisTmp = thisTmp->m_next;
    }
    
    m_top = newQueue.m_top;
    newQueue.m_top = nullptr;
    }

template <class T>
Queue<T>::~Queue<T>() {
     Node* tmp = m_top;
     Node* toDelete = m_top;
     while (tmp != nullptr) {
         tmp = tmp->m_next;
         delete toDelete;
         toDelete = tmp;
     }
}


template<class T>
Queue<T>& Queue<T>::operator=(const Queue<T>& other)
{
    if (this == &other)
    {
        return *this;
    }

    Queue<T> temp;
    const Node* node = other.m_top;

    while (node != NULL)
    {
        temp.pushBack(node->m_data);
        node = node->m_next;
    }

    while (this->m_top)
    {
        this->popFront();
    }

    m_top = temp.m_top;
    temp.m_top = NULL;
    return *this;
}

template <class T>
const int Queue<T>::size() const {
    if (m_top == nullptr) {
        return 0;
    }
    int count = 1;
    Node* tmp = m_top;
    while (tmp->m_next != nullptr) {
        tmp = tmp->m_next;
        ++count;
    }
    return count;
}

template <class T>
void Queue<T>::pushBack(const T& data) {
    if(this->size() == 0){
        m_top = new Node(data);
        return;
    }
    Node* tmp = m_top;
    while (tmp->m_next != nullptr) {
        tmp = tmp->m_next;
    }
    tmp->m_next = (new Node(data));

}

template <class T>
T& Queue<T>::front() {
    if(this->size() == 0) {
        throw EmptyQueue();
    }
    return this->m_top->m_data;
}

template <class T>
const T& Queue<T>::front() const {
    if(this->size() == 0) {
        throw EmptyQueue();
    }
    return m_top->m_data;
}

template <class T>
void Queue<T>::popFront() {
    if (this->size() == 0) {
        throw EmptyQueue();
    }
    Node* toDelete = m_top;
    m_top = m_top->m_next;
    delete toDelete;
}

template <class T>
typename Queue<T>::Iterator Queue<T>::begin() {
    return Iterator(m_top);
}

template <class T>
typename Queue<T>::Iterator Queue<T>::end() {
    return Iterator(nullptr);
}

template <class T>
typename Queue<T>::ConstIterator Queue<T>::begin() const {
    return ConstIterator(m_top);
}

template <class T>
typename Queue<T>::ConstIterator Queue<T>::end() const {
    return ConstIterator(nullptr);
}



template<class T, class Condition>
Queue<T> filter (const Queue<T>& queue , Condition c) {
    Queue<T> newQueue;
    for (const T& elem : queue) {
        if (c(elem)) {
            newQueue.pushBack(elem);
        }
    }
    return newQueue;
}

template<class T,class Condition>
void transform (Queue<T>& queue , Condition c) {
   for (T& elem : queue) {
        c(elem);
    }
}

///////////////class Node////////////////

template <class T>
class Queue<T>::Node{
private:
    T m_data;
    Node* m_next;
    friend class Queue<T>;

public:
    
    /*
     * Copy Constructor of Node class
    *
    * @param Queue - a const reference to Node.
    * @return   A new instance of Node.
    */
    explicit Node (const T& t);

    
    /*
     * Here we are explicitly telling the compiler to use the default methods
     */
    Node (const Node& node) = default;
    ~Node() = default;
    Node& operator=(const Node& other) = default;
};

template <class T>
Queue<T>::Node::Node(const T& t) :
m_data (t) ,
m_next (nullptr) {}

/////////////////class Iterator/////////////////////
template <class T>
class Queue<T>::Iterator {
private:
    Node* m_node;

    
    /*
     * C'tor of Queue<T>::Iterator class
     *
     * @param Queue - pointer to Node.
     * @param index - the index to which the iterator points inside the queue.
     * @return
     *      A new instance of Iterator.
    */
    explicit Iterator(Node* node);
    friend class Queue<T>;

public:

    /*
    * operator * of Queue<T>::Iterator
    *
    * @return
    *      A reference to T type object
    */
    T& operator*() const;

    
    /*
    * operator ++ from the left of Queue<T>::Iterator
    *
    * @return
    *      A reference to iterator pointing to next index.
    */
    Iterator& operator++();

    
    /*
    * operator ++ from the right of Queue<T>::Iterator
    *
    * @return
    *      Iterator pointing to same index after increasing its index member by 1.
    */
    Iterator operator++(int);

    
    /*
    * operator != of Queue<T>::Iterator
    *
    * @param other - a const reference to a Iterator instance
    * @return
    *      false - if both Iterator members are equals
    *      true - if one of the members are not equal
    */
    bool operator!=(const Iterator& other) const;

    
    /*
    * EmptyQueue class inside Queue<T>::Iterator class to allow exception throwing.
    *
   */
    class InvalidOperation{};

    
    /*
     * Here we are explicitly telling the compiler to use the default methods
     */
    Iterator(const Iterator&) = default;
    ~Iterator() = default;
    Iterator& operator=(const Iterator&) = default;
};

template <class T>
Queue<T>::Iterator::Iterator(Node* node):
m_node(node){}

template <class T>
T& Queue<T>::Iterator::operator*() const {
    return m_node->m_data;
}

template <class T>
typename Queue<T>::Iterator& Queue<T>::Iterator::operator++() {
    if (m_node == nullptr) {
        throw InvalidOperation();
    }
    m_node = m_node->m_next;
    return *this;
}

template<class T>
typename Queue<T>::Iterator Queue<T>::Iterator::operator++(int)
{
    if (m_node == NULL)
    {
        throw InvalidOperation();
    }
    Queue<T>::Iterator temp=*this;
    m_node = m_node->m_next;
    return temp;
}

template <class T>
bool Queue<T>::Iterator::operator!=(const Iterator& other) const {
    return m_node != other.m_node;
}

/////////////////class ConstIterator/////////////////////
template <class T>
class Queue<T>::ConstIterator {
private:
    const Node* m_node;

    
    /*
    * C'tor of Queue<T>::ConstIterator class
    *
    * @param Queue - const pointer to Node.
    * @param index - the index to which the iterator points inside the queue.
    * @return
    *      A new instance of Iterator.
   */
    explicit ConstIterator(const Node* node);
    friend class Queue<T>;

public:
    
    /*
    * operator * of Queue<T>::ConstIterator
    *
    * @return
    *      A reference to T type object
    */
    const T& operator*() const;

    
    /*
    * operator ++ from the left of Queue<T>::ConstIterator
    *
    * @return
    *      A reference to const iterator pointing to next index.
    */
    ConstIterator& operator++();

    
    /*
    * operator ++ from the right of Queue<T>::ConstIterator
    *
    * @return
    *      Const iterator pointing to same index after increasing its index member by 1.
    */
    ConstIterator operator++(int);

    
    /*
    * operator != of Queue<T>::ConstIterator
    *
    * @param other - a const reference to a ConstIterator instance
    * @return
    *      false - if both ConstIterator members are equals
    *      true - if one of the members are not equal
    */
    bool operator!=(const ConstIterator& other) const;

    
    /*
    * InvalidOperation class inside Queue<T>::ConstIterator class to allow exception throwing.
    *
   */
    class InvalidOperation{};

    
    /*
    * Here we are explicitly telling the compiler to use the default methods
   */
    ConstIterator(const ConstIterator&) = default;
    ConstIterator& operator=(const ConstIterator&) = default;
    ~ConstIterator() = default;


};

template <class T>
Queue<T>::ConstIterator::ConstIterator(const Node* node):
        m_node(node){}

template <class T>
const T& Queue<T>::ConstIterator::operator*() const {
    return m_node->m_data;
}

template <class T>
typename Queue<T>::ConstIterator& Queue<T>::ConstIterator::operator++() {
    if (m_node == nullptr) {
        throw InvalidOperation();
    }
    m_node = m_node->m_next;
    return *this;
}

template<class T>
typename Queue<T>::ConstIterator Queue<T>::ConstIterator::operator++(int)
{
    if (m_node == NULL)
    {
        throw InvalidOperation();
    }
    Queue<T>::ConstIterator temp=*this;
    m_node = m_node->m_next;
    return temp;
}

template <class T>
bool Queue<T>::ConstIterator::operator!=(const ConstIterator& other) const {
    return m_node != other.m_node;
}


#endif //EX3_QUEUE_H
