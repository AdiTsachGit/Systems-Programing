//
// Created by User on 05/01/2023.
//

#include "Ninja.h"

const std::string Ninja::TYPE = "Ninja";

Ninja::Ninja(std::string name, int max_HP, int force) : Player(name , max_HP , force){}

void Ninja::addCoins(int coinsToAdd) {
    if(coinsToAdd > 0){
        m_coins += coinsToAdd*2;
    }
}


std::ostream& Ninja::printInfo(std::ostream& os) const {
    printPlayerDetails(os, m_name, Ninja::TYPE, m_level, m_force, m_HP, m_coins);
    return os;
}


