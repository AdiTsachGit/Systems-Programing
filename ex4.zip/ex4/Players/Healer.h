//
// Created by User on 05/01/2023.
//
#include "Player.h"
#include "../utilities.h"


#ifndef EX4_HEALER_H
#define EX4_HEALER_H


class Healer : public Player {
public:
    static const std::string TYPE;

/*
     * constructor for subclass Healer
     *
     * @param name - the name of the Healer, Passed to baseclass Player
     *
     * @return
     *      a new instance of Healer
     */
    explicit Healer(std::string name , int max_HP = DEFUALT_MAX_HP ,  int force = DEFUALT_FORCE);

    void heal (int healPoints) override;


    /*
     * prints information about the player
     * @param os- the output stream to print to.
     * @return - the output stream to which the function has printed
     */
    std::ostream& printInfo(std::ostream& os) const override;

};


#endif //EX4_HEALER_H
