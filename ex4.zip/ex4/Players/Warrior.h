//
// Created by User on 05/01/2023.
//
#include "Player.h"
#include "../utilities.h"


#ifndef EX4_WARRIOR_H
#define EX4_WARRIOR_H


class Warrior : public Player{
public:
    static const std::string TYPE;
/*
     * constructor for subclass Warrior
     *
     * @param name - the name of the warrior, Passed to baseclass Player
     *
     * @return
     *      a new instance of Warrior
     */
    explicit Warrior(std::string name , int max_HP = DEFUALT_MAX_HP ,  int force = DEFUALT_FORCE);

    /*
    * adds to the hp of the Player
    *
    * @param amount - the amount of hp to be added to the Warrior according to Warrior stipulations
    * @return
    *      void
    */
    int getAttackStrength() const override;

    /*
     * prints information about the player
     * @param os- the output stream to print to.
     * @return - the output stream to which the function has printed
     */
    std::ostream& printInfo(std::ostream& os) const override;


};


#endif //EX4_WARRIOR_H
