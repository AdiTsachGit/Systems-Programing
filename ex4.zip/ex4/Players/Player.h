//
// Created by User on 06/01/2023.
//

#ifndef EX4_PLAYER_H
#define EX4_PLAYER_H



#include <string>


#define DEFUALT_FORCE 5
#define DEFUALT_MAX_HP 100

class Player {
protected:
    std::string m_name;
    int m_level;
    int m_force;
    int m_max_HP;
    int m_HP;
    int m_coins;


public:
    /*
    * C'tor for Player class:
    * @param playerName - player name received from user
    * @param hp - max HP of the player
    * @param force - starting force of the player
    * @param level - initial level (always starts from 1)
    * @param coins - initial amount of coins (always starts from 0)
    * @return
    *      A new instance of Player
    */
    explicit Player (std::string name , int max_HP = DEFUALT_MAX_HP ,  int force = DEFUALT_FORCE);

    /*
     * Copy C'tor for class Player
     * default is used
     */
    Player (const Player& player) = default;

    /*
     * D'tor for class Player
     * default is used
     */
    virtual ~Player()=default;
//changed it to be virtual cuz we need to in order for destructor to function right^
    /*
     * allows assignment of Player to Player
     * default is used
     */
    Player& operator=(const Player&) = default;

    /*
     * prints Player's info
     *
     * @param os- the output stream to print to.
     * @return
     *      output stream to which the function printed
     */
    virtual std::ostream& printInfo(std::ostream& os) const=0;

    /*
     * adds 1 to Player's level
     *
     * @return
     *      void
     */
    void levelUp();

    /*
     * returns level of the Player
     *
     * @return
     *      the level of the player as int
     */
    int getLevel() const;

    /*
     * adds to force of Player
     *
     * @param amount - amount of force to be added to the Player
     * @return
     *      void
     */
    void buff(int forcePoints);



    /*
     * adds to force of Player
     *
     * @param amount - amount of force to be added to the Player
     * @return
     *      void
     */
    void debuff(int forcePoints);

    /*
     * adds to hp of the Player
     *
     * @param amount - amount of hp to be added to the Player
     * @return
     *      void
     */
    virtual void heal (int healPoints);


    /*
     * reduces Player health
     *
     * @param amount - amount of hp to be reduced from Player
     * @return
     *      void
     */
    void damage (int damagePoints);

    /*
     * returns if the Player's hp reduced to 0
     *
     * @return
     *      true - Player's hp reduced to 0
     *      false - Player's hp is above 0
     */
    bool isKnockedOut() const;

    /*
     * adds to member coins of Player
     *
     * @param amount - amount of coins to be added
     * @return
     *      void
     */
    virtual void addCoins(int coinsToAdd);


    /*
     * reduces coins from Player if he has enough coins
     *
     * @param amount - amount to be reduced from coins
     * @return
     *      true - Player has enough coins to pay (coins reduced)
     *      false - Player doesn't have enough coins to pay (coins not reduced)
     */
    bool pay(int coinsToPay);

    /*
     * returns combined strength of attack (level + force)
     *
     * @return
     *      strength of attack
     */
    virtual int getAttackStrength() const;



    /*
     * returns the player's name.
     *
     * @return
     *      player's name
     */
     std::string getName() const;


    /*
    * returns the amount of coins a player has
    *
    * @return
    *      amount of coins
    */
     int getCoins() const;



    /*
    * returns the amount of HP a player has
    *
    * @return
    *      amount of HP
    */
    int getHP() const;




    /*
     * friended in order to overload printing operator
     */
    friend std::ostream& operator<< (std::ostream& os , const Player& player);

};




#endif //EX4_PLAYER_H
