//
// Created by User on 05/01/2023.
//

#include "Warrior.h"


const std::string Warrior::TYPE = "Warrior";


Warrior::Warrior(std::string name, int max_HP, int force) : Player(name , max_HP , force){}

int Warrior::getAttackStrength() const {
    return (2*m_force + m_level);
}


std::ostream& Warrior::printInfo(std::ostream& os) const {
    printPlayerDetails(os, m_name, Warrior::TYPE, m_level, m_force, m_HP, m_coins);
    return os;
}

