//
// Created by User on 05/01/2023.
//

#include "Healer.h"

const std::string Healer::TYPE = "Healer";


Healer::Healer(std::string name, int max_HP, int force) : Player(name , max_HP , force){}

void Healer::heal(int healPoints) {
    if (healPoints > 0) {
        m_HP += healPoints*2;
        if (m_HP > m_max_HP) {
            m_HP = m_max_HP;
        }
    }
}


std::ostream& Healer::printInfo(std::ostream& os) const {
    printPlayerDetails(os, m_name, Healer::TYPE, m_level, m_force, m_HP, m_coins);
    return os;
}
