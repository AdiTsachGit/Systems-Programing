//
// Created by Adi on 06/01/2023.
//

#ifndef EX4_EXCEPTION_H
#define EX4_EXCEPTION_H

#include <string>


/*
 * thrown if a file can't be opened using the provided path
 */
class DeckFileNotFound : public std::runtime_error {
public:
    DeckFileNotFound() : std::runtime_error("Deck File Error: File not found") {};
};


/*
 * thrown if the deck has less than five cards
 */
class DeckFileInvalidSize : public std::runtime_error {
public:
    DeckFileInvalidSize() : std::runtime_error("Deck File Error: Deck size is invalid") {};
};


/*
 * thrown if one of the lines in the file foes not correspond to a card in the game
 */
class DeckFileFormatError : public std::runtime_error {
public:
    explicit DeckFileFormatError(int line) : std::runtime_error(
            "Deck File Error: File format error in line " + std::to_string(line)) {};
};

#endif //EX4_EXCEPTION_H
