//
// Created by Adi on 05/01/2023.
//


#include "Well.h"
#include "../Players/Ninja.h"


const std::string Well::TYPE = "Well";


Well::Well() : Card(),
                     m_damage(Well::defWellDamage)
{}


void Well::applyEncounter(Player& player) const {
    Ninja* ptr = dynamic_cast<Ninja*>(&player);
    bool isNinja = ptr != nullptr;
    if (!isNinja) {
        player.damage(m_damage);
    }
    printWellMessage(isNinja);
}


std::ostream& Well::printInfo(std::ostream &out) const
{
    printCardDetails(out,Well::TYPE);
    printEndOfCardDetails(out);
    return out;
}


