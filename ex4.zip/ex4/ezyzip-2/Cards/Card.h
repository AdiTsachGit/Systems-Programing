//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_CARD_H
#define EX4_CARD_H


#include "../Players/Player.h"
#include <string>
#include "../utilities.h"


class Card {
public:
/*
 * constructor of class Card.
 */
    Card();

    virtual ~Card() = default;

    Card(const Card& card) = default;

    Card& operator=(const Card& other) = default;

    /*
     * Handling the player's a  pplyEncounter with the card:
     *
     * @param player - The player.
     * @return
     *      void
    */
    virtual void applyEncounter(Player& player) const = 0;

    /*
     * Prints the card info:
     *
     * @param os- the output stream to print to.
     * @return - the output stream to which the function has printed
    */

    virtual std::ostream& printInfo(std::ostream& out) const = 0;


    /*
    * friended in order to overload printing operator
    */
    friend std::ostream &operator<<(std::ostream &out, const Card& card);

};

#endif //EX4_CARD_H
