//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_BATTLE_H
#define EX4_BATTLE_H


#include "Card.h"


class Battle : public Card {
public:
/*
 * constructor of Battle class. Initials the common parameters that belong to all battle cards.
 * Can be used just from the sons constructors.
 */
    Battle(int m_force, int m_loot, int m_damage, const std::string& m_type);

    virtual ~Battle() = default;

    Battle(const Battle& card) = default;

    Battle& operator=(const Battle& other) = default;

    /*
     * Handling the player's applyEncounter with the card:
     *
     * @param player - The player.
     * @return
     *      void
    */
    void applyEncounter(Player& player) const override;



    /*
     * Handling the cards's effect on a player:
     *
     * @param player - The player.
     * @return
     *      void
    */
    virtual void applyEffect(Player& player) const = 0;



    /*
     * Prints the card info
     *
     * @param os- the output stream to print to.
     * @return - the output stream to which the function has printed
    */
    std::ostream& printInfo(std::ostream& out) const override;


private:
    int m_force;
    int m_loot;
    int m_damage;
    std::string m_type;
};


#endif //EX4_BATTLE_H
