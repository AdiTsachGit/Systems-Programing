//
// Created by Adi on 05/01/2023.
//

#include "Barfight.h"
#include "../Players/Warrior.h"




const std::string Barfight::TYPE = "Barfight";


Barfight::Barfight() : Card(),
                       m_damage(Barfight::barDamage)
{}



void Barfight::applyEncounter(Player& player) const {
    Warrior* ptr = dynamic_cast<Warrior*>(&player);
    bool isWarrior = ptr != nullptr;
    if (!isWarrior) {
        player.damage(m_damage);
    }
    printBarfightMessage(isWarrior);
}

std::ostream& Barfight::printInfo(std::ostream &out) const
{
    printCardDetails(out,Barfight::TYPE);
    printEndOfCardDetails(out);
    return out;
}



