//
// Created by Adi on 05/01/2023.
//


#include "Treasure.h"


const std::string Treasure::TYPE = "Treasure";


Treasure::Treasure() : Card(),
                       m_loot(Treasure::defLootAmount)
{}


void Treasure::applyEncounter(Player& player) const {
    player.addCoins(m_loot);
    printTreasureMessage();
}


std::ostream& Treasure::printInfo(std::ostream &out) const
{
    printCardDetails(out,Treasure::TYPE);
    printEndOfCardDetails(out);
    return out;
}



