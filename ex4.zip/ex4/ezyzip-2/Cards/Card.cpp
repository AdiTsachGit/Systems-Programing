//
// Created by Adi on 05/01/2023.
//

#include "Card.h"



Card::Card() = default;


std::ostream& operator<<(std::ostream &out, const Card& card)
{
    card.printInfo(out);
    return out;
}



