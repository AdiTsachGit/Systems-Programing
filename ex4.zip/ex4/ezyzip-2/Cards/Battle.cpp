//
// Created by Adi on 05/01/2023.
//

#include "Battle.h"


Battle::Battle(int force, int loot, int damage,const std::string& type) :
    m_force(force),
    m_loot(loot),
    m_damage(damage),
    m_type(type)
{}


void Battle::applyEncounter(Player& player) const {
    bool win = player.getAttackStrength() >= m_force;
    if (win)
    {
        player.levelUp();
        player.addCoins(m_loot);
        printWinBattle(player.getName(), m_type);
    }
    else
    {
        player.damage(m_damage);
        applyEffect(player);
        printLossBattle(player.getName(), m_type);

    }
}




std::ostream& Battle::printInfo(std::ostream &out) const
{
    printCardDetails(out,m_type);
    printMonsterDetails(out, m_force, m_damage, m_loot, true);
    printEndOfCardDetails(out);
    return out;
}
