//
// Created by Adi on 06/01/2023.
//

#include "Mtmchkin.h"

using namespace std;
#define PLAYER_NAME_MAX_LENGTH 15
#define PLAYER_NAME_MAX_LEVEL 10


Mtmchkin::Mtmchkin(const string& fileName): m_numOfRounds(0)
{
    printStartGameMessage();
    ifstream deck(fileName);
    createDeck(m_deck,fileName);
    int teamSize=0;
    getTeamSizeInput(teamSize);
    for (int i=0;i<teamSize;i++)
    {
        printInsertPlayerMessage();
        while (!createPlayer(m_players));
    }
}


int Mtmchkin::getNumberOfRounds() const {
    return m_numOfRounds;
}

void Mtmchkin::printLeaderBoard() const {
printLeaderBoardStartMessage();
int rank = 1;
for (const unique_ptr<Player>& ptr : m_winners) {
    printPlayerLeaderBoard(rank , *ptr);
    rank++;
}
for (const unique_ptr<Player>& ptr : m_players) {
    printPlayerLeaderBoard(rank , *ptr);
    rank++;
}
for (const unique_ptr<Player>& ptr : m_losers) {
    printPlayerLeaderBoard(rank , *ptr);
    rank++;
}
}

bool Mtmchkin::isGameOver() const {
    if (m_players.empty()) {
        return true;
    }
    return false;
}

void Mtmchkin::playRound()
{
    m_numOfRounds++;
    int playersSize = (int) m_players.size();
    printRoundStartMessage(this->getNumberOfRounds());
    for (int i = 0; i<playersSize ;i++)
    {
        printTurnStartMessage(m_players[i]->getName());
        m_deck.front()->applyEncounter(*(m_players[i]));
        if (m_players[i]->getLevel()>= PLAYER_NAME_MAX_LEVEL)
        {
            m_winners.push_back(move(m_players[i]));
            m_players.erase(m_players.begin()+i);
            i--;
        }
        else if(m_players[i]->isKnockedOut())
        {
            m_losers.push_front(move(m_players[i]));
            m_players.erase(m_players.begin()+i);
            i--;
        }

        unique_ptr<Card> tempCard(move(m_deck.front()));
        m_deck.pop_front();
        m_deck.push_back(move(tempCard));
        if (isGameOver())
        {
            printGameEndMessage();
            break;
        }
        playersSize = (int) m_players.size();
    }
}




void Mtmchkin::createDeck(list<unique_ptr<Card>>& deck,const string& filename)
{
    int cardNumber =0;
    int deckLine =1;
    string tempCard;
    ifstream tmp(filename);
    if (!tmp)
    {
        throw DeckFileNotFound();
    }
    while (getline(tmp,tempCard))
    {
        if (tempCard == "Barfight") {
            deck.push_back(unique_ptr<Card>(new Barfight));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Dragon") {
            deck.push_back(unique_ptr<Card>(new Dragon));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Gremlin") {
            deck.push_back(unique_ptr<Card>(new Gremlin));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Mana") {
            deck.push_back(unique_ptr<Card>(new Mana));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Merchant") {
            deck.push_back(unique_ptr<Card>(new Merchant));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Treasure") {
            deck.push_back(unique_ptr<Card>(new Treasure));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Well") {
            deck.push_back(unique_ptr<Card>(new Well));
            cardNumber++;
            deckLine++;
        }
        else if (tempCard == "Witch") {
            deck.push_back(unique_ptr<Card>(new Witch));
            cardNumber++;
            deckLine++;
        }
        else
        {
            throw DeckFileFormatError(deckLine);
        }
    }
    if (cardNumber<5)
    {
        throw DeckFileInvalidSize();
    }
}


bool Mtmchkin::createPlayer(vector<unique_ptr<Player>>& list)
{
    string name,job;
    getline(cin , name , ' ');
    getline(cin , job);

    if (checkInvalidName(name))
    {
        printInvalidName();
        return false;
    }
    if (job == Healer::TYPE)
    {
        list.push_back(unique_ptr<Player>(new Healer(name)));
    }
    else if (job == Warrior::TYPE)
    {
        list.push_back(unique_ptr<Player>(new Warrior(name)));
    }
    else if (job == Ninja::TYPE)
    {
        list.push_back(unique_ptr<Player>(new Ninja(name)));
    }
    else
    {
        printInvalidClass();
        return false;
    }
    return true;
}


bool Mtmchkin::checkInvalidName (string& name) {
    if (name.length() > PLAYER_NAME_MAX_LENGTH) {
        return true;
    }
    for (char i : name) {
        if (isalpha(i) == 0) {
            return true;
        }
    }
    return false;
}


void Mtmchkin::getTeamSizeInput(int& teamSize)
{
    string temp;
    while((teamSize>6)||(teamSize<2))
    {
        try{
            printEnterTeamSizeMessage();
            getline(cin,temp);
            teamSize = stoi(temp);
        }
        catch(const exception& e){
            printInvalidTeamSize();
            continue;
        }
        if ((teamSize>6)||(teamSize<2))
        {
            printInvalidTeamSize();
        }
    }
}