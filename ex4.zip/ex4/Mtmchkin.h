#ifndef MTMCHKIN_H_
#define MTMCHKIN_H_


#include <string>
#include "Cards/Card.h"
#include <list>
#include <vector>
#include <memory>

#include <fstream>
#include "Exception.h"
#include "Players/Player.h"

#include "Cards/Barfight.h"
#include "Cards/Dragon.h"
#include "Cards/Gremlin.h"
#include "Cards/Mana.h"
#include "Cards/Merchant.h"
#include "Cards/Treasure.h"
#include "Cards/Well.h"
#include "Cards/Witch.h"

#include "Players/Ninja.h"
#include "Players/Healer.h"
#include "Players/Warrior.h"

using namespace std;



class Mtmchkin{
public:

    /*
    * C'tor of Mtmchkin class
    *
    * @param filename - a file which contains the cards of the deck.
    * @return
    *      A new instance of Mtmchkin.
    */
    explicit Mtmchkin(const string &fileName);

    /*
    * Play the next Round of the game - according to the instruction in the exercise document.
    *
    * @return
    *      void
    */
    void playRound();

    /*
    * Prints the leaderBoard of the game at a given stage of the game - according to the instruction in the exercise document.
    *
    * @return
    *      void
    */
    void printLeaderBoard() const;

    /*
    *  Checks if the game ended:
    *
    *  @return
    *          True if the game ended
    *          False otherwise
    */
    bool isGameOver() const;

	/*
    *  Returns the number of rounds played.
    *
    *  @return
    *          int - number of rounds played
    */
    int getNumberOfRounds() const;

private:
    int m_numOfRounds;
    list<unique_ptr<Card>> m_deck;
    vector<unique_ptr<Player>> m_players;
    list<unique_ptr<Player>> m_winners;
    list<unique_ptr<Player>> m_losers;


/*
 * gets the team size from the user and checks if it follows the provided rules (2-6 players)
 *
 * @param teamSize - the teamSize scanned from the user
 */
    static void getTeamSizeInput (int& teamSize);


/*
 * creates a unique pointer to an appropriate subclass of Player according to user input, and places it in a vector
 *
 * @param list - a vector to which Player subclass unique pointers will be added
 * @return
 *      false - the Player cannot be created according to the rules
 *      true - the Player was created according to the rules
 */

    static bool createPlayer(vector<unique_ptr<Player>>& list);


/*
 * creates a queue of unique pointers to Card subclasses from a provided file
 * (in each line in the file there should be a single word corresponding to a Card subclass, otherwise an exception is thrown)
 *
 * @param deck - a queue of unique pointers to the Cards in the game
 * @param fileName - the name of the file from which the Card types will be drawn
 * @return
 *      void
 */
    static void createDeck(list<unique_ptr<Card>>& deck, const string& filename);

    /*
* checks if the name provided follows the provided rules (english letters only, up to 15 characters)
*
* @param name - the name scanned from the user
* @return
*      true - the name follows the rules
*      false - the name does not follow the rules
*/
    static bool checkInvalidName(string& name);
};



#endif /* MTMCHKIN_H_ */
