//
// Created by Adi on 05/01/2023.
//


#include "Gremlin.h"

const std::string Gremlin::TYPE = "Gremlin";

//Battle(int m_force, int m_loot, int m_damage);


Gremlin::Gremlin() : Battle(gremForce, gremLoot, gremDamage, TYPE) {}

void Gremlin::applyEffect(Player& player) const {
    //we do nothing here
}

