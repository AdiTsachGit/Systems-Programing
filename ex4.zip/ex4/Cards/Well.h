//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_WELL_H
#define EX4_WELL_H



#include "Card.h"


/*
 * damages every type of Player except Ninja
 */
class Well : public Card {
public:
    /*
     * C'tor of Well class
     *
     * @return
     *      A new instance of Well.
    */
    Well();


    /*
     * Handling the player's applyEncounter with the card:
     *
     * @param player - The player to which the result of the encounter will be dealt.
     * @return
     *      void
    */
    void applyEncounter(Player& player) const override;


    /*
     * Prints the card info:
     *
     * @param os- the output stream to print to.
     * @return - the output stream to which the function has printed
    */
    void printInfo(std::ostream &out) const override;




    /*
     * Here we are explicitly telling the compiler to use the default methods
    */
    Well(const Well&) = default;
    ~Well() override = default;
    Well& operator=(const Well& other) = default;

    /*
     * the type of the Card (Well)
     */
    static const std::string TYPE;
    static const int defWellDamage = 10;

private:
    int m_damage;
};


#endif //EX4_WELL_H
