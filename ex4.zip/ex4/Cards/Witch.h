//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_WITCH_H
#define EX4_WITCH_H



#include "Battle.h"



class Witch : public Battle {
public:
    /*
     * C'tor of Witch class
     *
     * @return
     *      A new instance of Witch.
    */
    explicit Witch();



    /*
     * Handling the cards's effect on a player:
     *
     * @param player - The player.
     * @return
     *      void
    */
    void applyEffect(Player& player) const override;



    /*
     * Here we are explicitly telling the compiler to use the default methods
    */
    Witch(const Witch&) = default;
    ~Witch() override = default;
    Witch& operator=(const Witch& other) = default;

    /*
     * the type of the Card (Goblin)
     */
    static const std::string TYPE;
    static const int witchForce=11;
    static const int witchLoot=2;
    static const int witchDamage=10;
};


#endif //EX4_WITCH_H
