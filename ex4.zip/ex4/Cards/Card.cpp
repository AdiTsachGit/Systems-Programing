//
// Created by Adi on 05/01/2023.
//

#include "Card.h"



Card::Card() = default;


void operator<<(std::ostream &out, const Card& card)
{
    card.printInfo(out);
}



