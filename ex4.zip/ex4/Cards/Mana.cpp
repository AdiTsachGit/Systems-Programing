//
// Created by Adi on 05/01/2023.
//



#include "Mana.h"
#include "../Players/Healer.h"

const std::string Mana::TYPE = "Mana";


Mana::Mana() : Card(),
                 m_heal(Mana::ManaHeal)
{}


void Mana::applyEncounter(Player& player) const {
    Healer* ptr = dynamic_cast<Healer*>(&player);
    bool isHealer = ptr != nullptr;
    printManaMessage(isHealer);
    if (!isHealer) {
        return;
    }
    player.heal(m_heal);
}

void Mana::printInfo(std::ostream &out) const
{
    printCardDetails(out,Mana::TYPE);
    printEndOfCardDetails(out);
}




