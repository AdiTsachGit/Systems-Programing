//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_GREMLIN_H
#define EX4_GREMLIN_H



#include "Battle.h"

class Gremlin : public Battle {
public:
    /*
     * C'tor of Gremlin class
     *
     * @return
     *      A new instance of Gremlin.
    */
    Gremlin();


    /*
     * Handling the cards's effect on a player:
     *
     * @param player - The player.
     * @return
     *      void
    */
    void applyEffect(Player& player) const override;



    /*
     * Here we are explicitly telling the compiler to use the default methods
    */
    Gremlin(const Gremlin&) = default;
    ~Gremlin() override = default;
    Gremlin& operator=(const Gremlin& other) = default;

    /*
     * the type of the Card (Gremlin)
     */
    static const std::string TYPE;
    static const int gremForce = 5;
    static const int gremLoot = 2;
    static const int gremDamage = 10;

};

#endif //EX4_GREMLIN_H
