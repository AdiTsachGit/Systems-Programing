//
// Created by Adi on 05/01/2023.
//


#include "Witch.h"
#include "Battle.h"


const std::string Witch::TYPE = "Witch";

//Battle(int m_force, int m_loot, int m_damage);

Witch::Witch() : Battle(witchForce,witchLoot, witchDamage, TYPE) {}



void Witch::applyEffect(Player& player) const {
    player.debuff(1);
}

