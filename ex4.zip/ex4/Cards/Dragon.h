//
// Created by Adi on 05/01/2023.
//

#ifndef EX4_DRAGON_H
#define EX4_DRAGON_H



#include "Battle.h"



class Dragon : public Battle {
public:
    /*
     * C'tor of Dragon class
     *
     * @return
     *      A new instance of Dragon.
    */
    Dragon();


    /*
     * Handling the cards's effect on a player:
     *
     * @param player - The player.
     * @return
     *      void
    */
    void applyEffect(Player& player) const override;



    /*
     * Here we are explicitly telling the compiler to use the default methods
     */
    Dragon(const Dragon&) = default;
    ~Dragon() override = default;
    Dragon& operator=(const Dragon& other) = default;


    /*
     * the type of the Card (Dragon)
     */
    static const std::string TYPE;
    static const int dragForce = 25;
    static const int dragLoot = 1000;
    static const int dragDamage = 0;


};


#endif //EX4_DRAGON_H
