//
// Created by Adi on 05/01/2023.
//


#include "Dragon.h"

const std::string Dragon::TYPE = "Dragon";


Dragon::Dragon() : Battle(dragForce, dragLoot, dragDamage, TYPE) {}


void Dragon::applyEffect(Player& player) const {
    int damage = player.getHP();
    player.damage(damage);
}




