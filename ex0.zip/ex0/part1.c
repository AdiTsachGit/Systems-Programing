#include <stdio.h>
#include <stdlib.h>

int main() {

    int inputSize;
    printf("Enter size of input:\n");

    if((scanf(" %d", &inputSize)) == 0)
    {
        return 0;
    }
    if (inputSize <= 0)
    {
        printf("Invalid size\n");
        return 0;
    }

    int *numbers;
    numbers = (int *) malloc(sizeof(int) * inputSize);

    if (numbers == NULL)
    {
        printf("Dynamic Allocation Error");
        return 0;
    }

    printf("Enter numbers:\n");
    for (int i = 0; i < inputSize; i++)
        if ((scanf(" %d", (numbers + i))) == 0)
        {
            printf("Invalid number\n");
            free(numbers);
            return 0;
        }

    int exponentCounter = 0;
    int temp;
    int exponentSum = 0;

    for (int j = 0; j < inputSize; j++)
    {
        temp = 1;
        while(temp < *(numbers + j))
        {
            temp *= 2;
            exponentCounter++;
        }
        if (temp == *(numbers + j))
        {
            printf("The number %d is a power of 2: %d = 2^%d\n", temp, temp, exponentCounter);
            exponentSum += exponentCounter;
        }
        exponentCounter = 0;
    }

    printf("Total exponent sum is %d\n", exponentSum);

    free(numbers);
    return 0;
}
