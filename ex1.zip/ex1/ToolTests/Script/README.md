# Notes
Please put these files in the code folder

# Run in your terminal
./tester.sh AsciiArtTool [Directory of the tests]
