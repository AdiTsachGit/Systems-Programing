#include "RLEList.h"
#include <stdio.h>
#include "AsciiArtTool.h"
#include <stdlib.h>

#define BUFFER_SIZE 2


RLEList asciiArtRead(FILE* in_stream) {
    RLEList list = RLEListCreate();
    if(!list) {
        return NULL;
    }
    RLEList ptr = list;
    char buffer[BUFFER_SIZE] = "";
    while(fgets(buffer , BUFFER_SIZE , in_stream) != NULL) {
        if(RLEListAppend(ptr , buffer[0]) != RLE_LIST_SUCCESS) {
            return list;
        }
    }
    return list;
}


RLEListResult asciiArtPrint(RLEList list, FILE* out_stream) {
    int size = RLEListSize(list);
    if (size == -1) {
        return RLE_LIST_ERROR;
    }
    RLEListResult result;
    char buffer[] = {'\0' ,'\0'};
    for(int i = 0 ; i < size ; i++ ) 
    {
        buffer[0] = RLEListGet(list , i , &result);
        if (buffer[0] == 0) {
            return result;
        }
        fputs(buffer , out_stream);
    }
    return result;
}



RLEListResult asciiArtPrintEncoded(RLEList list, FILE *out_stream) {
    if(list == NULL || out_stream == NULL) {
        return RLE_LIST_NULL_ARGUMENT;
    }
    
    RLEListResult result;
    char* str = RLEListExportToString(list , &result);
    if (str == NULL) {
        return result;
    }

    if (fputs (str , out_stream) == EOF) {
        free (str);
        return RLE_LIST_ERROR;
    }

    free(str);
    return RLE_LIST_SUCCESS;
}

