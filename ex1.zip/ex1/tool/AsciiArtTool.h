//
// Created by User on 18/11/2022.
//

#ifndef TESTS_ASCIIARTTOOL_H
#define TESTS_ASCIIARTTOOL_H


/**
*  asciiArtRead: reads given file and compress it using RLE method.
*
*@param in_stream - a type FILE* that contains a picture to compress.
*@return
*    RLEList that contains the picture's data.
*/
RLEList asciiArtRead(FILE* in_stream);

/**
*  asciiArtPrint: prints a picture given as RLEList into an output file.
*
*@param list - the RLE list that containsl the picture's characters.
*@param out_stream - a type FILE*, where we write the picture to.
*@return
*    LIST_ERROR_RLE if an error happened in attempted execution.
*/
RLEListResult asciiArtPrint(RLEList list, FILE *out_stream);


/**
*  asciiArtPrintEncoded: writes picture into file in the compressed method.
*
*@param list - RLE list containing the characters in given picture.
*@param out_stream - a type FILE* to which we write the compressed picture.
*@return
*    RLE_LIST_NULL_ARGUMENT if any parameter is NULL
*    RLE_LIST_SUCCESS if attempt was successful
*/
RLEListResult asciiArtPrintEncoded(RLEList list, FILE *out_stream);



#endif // ASCIIARTTOOL_H
