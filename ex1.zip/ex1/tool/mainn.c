#include <stdio.h>
#include "RLEList.h"
#include "AsciiArtTool.h"
#include <string.h>

char invertFunction(char data);

int main (int argc , char** argv) {
    if(argc != 4) {
        printf("Problem: unexpected amount of arguments %d",argc);
        return 0;
    }

    FILE* input = fopen (argv[2] , "r");
    if(!input) {
        printf("Error: can not open %s", argv[2]);
        fclose(input);
        return 0;
    }
    RLEList list = asciiArtRead(input);
    if(!list) {
        fclose(input);
        return 0;
    }
    fclose(input);

    FILE* output = fopen (argv[3] , "w");
    if(!output) {
        fclose(output);
        printf("Error: cannot open %s", argv[3]);
        RLEListDestroy(list);
        return 0;
    }


    if(strcmp(argv[1] , "-e") == 0) {
        if (asciiArtPrintEncoded(list , output) != RLE_LIST_SUCCESS)
        {
            printf("Error in AsciiArtPrintEncoded");
        }
    }

    else if(strcmp (argv[1] , "-i") == 0) {
        if(RLEListMap(list , &invertFunction) != RLE_LIST_SUCCESS) {
            fclose(output);
            printf("Error in RLEListMap");
            RLEListDestroy(list);
            return 0;
        }
        if(asciiArtPrint(list , output) != RLE_LIST_SUCCESS)
        {
            printf("Error in AsciiArtPrint");
        }
    }

    fclose(output);
    RLEListDestroy(list);
    return 0;
}




char invertFunction(char data) {
    if (data == '@') {
        return ' ';
    }
    else if (data == ' ') {
        return '@';
    }
    else {
        return data;
    }
}
