#include <iostream>
#include "Card.h"



void verification(int& a); // checks if the inserted number is negative and changes it to positive

Card::Card(CardType type, const CardStats& stats) :
m_effect(type),
m_stats(stats){}


void Card::applyEncounter(Player& player) const {
    if (m_effect == CardType::Treasure) {
        int loot = m_stats.loot;
        verification(loot);
        player.addCoins(loot);
    }

    else if (m_effect == CardType::Heal)
    {
        int cost = m_stats.cost;
        verification(cost);
        if (player.pay(cost)) {
            int heal = m_stats.heal;
            verification(heal);
            player.heal(heal);
        }
    }

    else if(m_effect == CardType::Buff) {
        int cost = m_stats.cost;
        verification(cost);
        if(player.pay(cost)) {
            int buff = m_stats.buff;
            verification(buff);
            player.buff(buff);
        }
    }

    else if(m_effect == CardType::Battle) {
        if (player.getAttackStrength() >= m_stats.force) {
            player.levelUp();
            int coins = m_stats.loot;
            verification(coins);
            player.addCoins(coins);
            printBattleResult(true);
        }
        else {
            int damage = m_stats.hpLossOnDefeat;
            verification(damage);
            player.damage(damage);
            printBattleResult(false);
        }
    }
}


void Card::printInfo() const {
    if(m_effect == CardType::Battle) {
        printBattleCardInfo(m_stats);
    }

    else if (m_effect == CardType::Buff){
        printBuffCardInfo(m_stats);
    }

    else if(m_effect == CardType::Heal) {
        printHealCardInfo(m_stats);
    }

    else {
        printTreasureCardInfo(m_stats);
    }
}

void verification(int& a) {
    if (a < 0)
    {
        a = 0;
    }
}


