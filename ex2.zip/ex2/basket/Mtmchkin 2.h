
#ifndef EX2_GAME_H
#define EX2_GAME_H
#include "Card.h"
#include "Player.h"
#include <iostream>

/*
 * GameStatus:
 * MidGame - The game is still active and the player continues to encounter cards.
 * Win - The player reached level 10.
 * Loss - The player's HP is 0.
*/
enum class GameStatus{Win, Loss, MidGame};

class Mtmchkin {
public:

    /*
     * C'tor of the game:
     *
     * @param playerName - The name of the player.
     * @param cardsArray - A ptr to the cards deck.
     * @param numOfCards - Num of cards in the deck.
     * @result
     *      An instance of Mtmchkin
    */
    Mtmchkin(const char* playerName, const Card* cardsArray, int numOfCards);

    /*
     * copy C'tor of the game:
     *
     * @param copyGame - other instance of the game to be copied
     * @result
     *      this new instance of the game is equivelent to copyGame
     */

    Mtmchkin(const Mtmchkin& copyGame);

    /*
     * D'tor of the game:
     *
     * @result:
     *      expilictly uses delete[]m_name, delete m_deck and destucts this instance of the game
     */
    ~Mtmchkin();

    /*
     * assignment operator of the game:
     *
     * @param copyGame - other instance of the game to be copied
     * @result
     *      this instance of the game is equivelent to copyGame
     */
    Mtmchkin& operator=(const Mtmchkin& copyGame);
    
    
    /*
     * Play the next Card - according to the instruction in the exercise document
     *
     * @return
     *      void
    */
    void playNextCard();


    /*
     *  Check if the game ended:
     *
     *  @return
     *          True if the game ended
     *          False otherwise
     */
    bool isOver() const;


    /*
     *  Get the status of the game:
     *
     *  @return
     *          GameStatus - the current status of the running game
     */
    GameStatus getGameStatus() const;

private:

    Card* m_deck;
    int m_cardsNumber;
    GameStatus m_status;
    int m_nextCard;
    Player m_player;
};


#endif //EX2_GAME_H
