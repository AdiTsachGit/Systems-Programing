
#include "Mtmchkin.h"
#include "Card.h"
#include "Player.h"

#include <string.h>

#define MAX_LEVEL 10


Mtmchkin::Mtmchkin(const char* playerName, const Card* cardsArray, int numOfCards):
m_cardsNumber(numOfCards), m_status(GameStatus::MidGame), m_nextCard(0), m_player(playerName)
{
    

    m_deck = new Card[numOfCards];
    for (int index = 0; index < numOfCards; index++)
    {
        m_deck[index] = cardsArray[index];
    }

}

Mtmchkin& Mtmchkin::operator=(const Mtmchkin& copyGame){
    delete [] m_deck;
    m_deck = new Card [copyGame.m_cardsNumber];
    for (int i=0;i<copyGame.m_cardsNumber;i++)
    {
        m_deck[i] = copyGame.m_deck[i];
    }
    m_cardsNumber = copyGame.m_cardsNumber;
    m_player = copyGame.m_player;
    m_status = copyGame.m_status;
    m_nextCard = copyGame.m_nextCard;
    return *this;
}

Mtmchkin::Mtmchkin(const Mtmchkin& copyGame) :
    m_cardsNumber(copyGame.m_cardsNumber),
    m_status(copyGame.m_status),
    m_nextCard(copyGame.m_nextCard),
    m_player(copyGame.m_player)
    {
    m_deck = new Card [copyGame.m_cardsNumber];
    for (int i=0;i<copyGame.m_cardsNumber;i++)
    {
        m_deck[i] = copyGame.m_deck[i];
    }
}

Mtmchkin::~Mtmchkin() {
    delete[] m_deck;
}
    
GameStatus Mtmchkin::getGameStatus() const{
    return this->m_status;
}

void Mtmchkin::playNextCard() {

    m_deck[m_nextCard].printInfo();
    m_deck[m_nextCard].applyEncounter(m_player);
    if (m_player.isKnockedOut())
    {
        m_status = GameStatus::Loss;
    }
    if (m_player.getLevel() == MAX_LEVEL)
    {
        m_status = GameStatus::Win;
    }
    
    m_player.printInfo();
    
    if (++m_nextCard == m_cardsNumber)
    {
        m_nextCard = 0;
    }
}

bool Mtmchkin::isOver() const {
    if (m_status != GameStatus::MidGame)
    {
        return true;
    }
    return false;
}
