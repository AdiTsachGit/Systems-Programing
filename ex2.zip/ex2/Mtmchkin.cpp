#include "Mtmchkin.h"
#include "Card.h"

#define WINNING_LEVEL 10

Mtmchkin::Mtmchkin(const char* playerName, const Card* cardsArray, int numOfCards) :
m_status (GameStatus::MidGame) ,
m_deck (new Card[numOfCards]) ,
m_cardToPlay(0),
m_player(playerName) ,
m_numOfCards(numOfCards){
    for (int i = 0 ; i < numOfCards ; ++i) {
        m_deck[i] = cardsArray[i];
    }
}

void Mtmchkin::playNextCard() {
    Card card = m_deck[m_cardToPlay];

    card.printInfo();
    card.applyEncounter(m_player);
    if(m_player.getLevel() == WINNING_LEVEL) {
        m_status = GameStatus::Win;
    }
    if (m_player.isKnockedOut()) {
        m_status = GameStatus::Loss;
    }

    m_player.printInfo();
    if (++m_cardToPlay == m_numOfCards) {
        m_cardToPlay = 0;
    }
}


bool Mtmchkin::isOver() const {
    if (m_status == GameStatus::Loss || m_status == GameStatus::Win) {
        return true;
    }
    return false;
}


GameStatus Mtmchkin::getGameStatus() const {
    return m_status;
}

Mtmchkin::Mtmchkin (const Mtmchkin& other) :
m_status (other.m_status) ,
m_deck(new Card[other.m_numOfCards]) ,
m_cardToPlay (other.m_cardToPlay) ,
m_player(other.m_player) ,
m_numOfCards (other.m_numOfCards) {
    for (int i = 0 ; i < m_numOfCards ; ++i) {
        m_deck[i] = other.m_deck[i];
    }
}

Mtmchkin::~Mtmchkin() {
    delete[] m_deck;
}

 Mtmchkin& Mtmchkin::operator=(const Mtmchkin &other) {
    m_status = other.m_status;
    m_cardToPlay = other.m_cardToPlay;
    m_numOfCards = other.m_numOfCards;
    m_player = other.m_player;
    Card* newDeck = new Card[other.m_numOfCards];
    for (int i = 0 ; i < m_numOfCards ; ++i) {
        newDeck[i] = other.m_deck[i];
    }
    delete[] m_deck;
    m_deck = newDeck;

    return *this;
}
